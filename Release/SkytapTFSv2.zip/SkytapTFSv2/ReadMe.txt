Skytap TFS Automation Pack v2.0

Full ocumentation on installing and using the Skytap
TFS Automation Pack can be found here:

http://help.skytap.com/#skytap_automation_pack_for_visual_studio_team_foundation_server

Below is a short version on how
to setup the Skytap TFS Automation pack.

Installing the skytapcli tool
=============================

The skytapcli.exe and the skytapcli.exe.conig 
files should be copied to the following location
on all build controllers:

c:\skytap\skytapcli.exe
c:\skytap\skytapcli.exe.config

This is to ensure that the build controllers can
setup the Skytap environments needed to running
BDT Tests


Installing the Skytap XAML
==========================

The SkytapLabDefaultTemplate.11.xaml file needs
to be added into TFS so that it can be used in 
build definitions that utilize Skytap for test
resources.  To do this copy SkytapLabDefaultTemplate.11.xaml 
into your TFS projects BuildProcessTemplates folder
and checked into TFS.


